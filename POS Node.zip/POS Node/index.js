var http = require('http');
var qs = require('querystring');
var url = require('url');
var fs = require('fs');
var dt = require('./Function.js');


var formOutput = '<html><head>'
  +'<title>Line Chart Test</title>'
  +'<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/1.0.2/Chart.min.js"></script>'
  +'<script language="JavaScript">'

  +'function displayAlert() {'
      +'alert("Hello World...");'
  +'}'
  
  +'function displayLinechart() {'
   // + 'alert("Hello World");'
+'var woche = ["Montag", "Dienstag", "Mittwoch", "Donnerstag", "Freitag", "Samstag", "Sonntag"];'  
+'var zahlen =  [9500, 9800, 8600, 8900, 10200, 12500, 6700];'
+'var mydata = [woche, zahlen];'
    
    
     
    
        +'var data = {'
        +'labels: mydata[0],'
        +'datasets: ['
            +'{'
                +'label: "Prime and Fibonacci",'
                +'fillColor: "rgba(220,220,220,0.2)",'
                +'strokeColor: "rgba(220,220,220,1)",'
                +'pointColor: "rgba(220,220,220,1)",'
                +'pointStrokeColor: "#fff",'
                +'pointHighlightFill: "#fff",'
                +'pointHighlightStroke: "rgba(220,220,220,1)",'
                +'data: mydata[1]'
            +'},'
            +'{'
                +'label: "My Second dataset",'
                +'fillColor: "rgba(151,187,205,0.2)",'
                +'strokeColor: "rgba(151,187,205,1)",'
                +'pointColor: "rgba(151,187,205,1)",'
                +'pointStrokeColor: "#fff",'
                +'pointHighlightFill: "#fff",'
                +'pointHighlightStroke: "rgba(151,187,205,1)",'
                +'data: [4567, 7000, 4573, 2, 6000, 5, 8]'
            +'}'
        +']'
    +'};'
    +'var ctx = document.getElementById("line-chart").getContext("2d");'
    +'new Chart(ctx).Line(data);'
    +'}' 

    + 'function displayDoughnutchart() {'
    +'var data = {'
    +'labels: ["M", "T", "W", "T", "F", "S", "S"],'
        +'datasets: [{'
            +'backgroundColor: ["#2ecc71","#3498db","#95a5a6","#9b59b6","#f1c40f","#e74c3c","#34495e"],'
            +'data: [12, 19, 3, 17, 28, 24, 7]'
        +'}]'
    +'};'
    
    + 'var ctx1 = document.getElementById("doughnut-chart").getContext("2d");'
    + 'new Chart(ctx1).Doughnut(data);'
    + '}'  

    +'function doughnutChart() {'
    +'var donutEl = document.getElementById("doughnut-chart").getContext("2d");'
        +'var donut = new Chart(donutEl).Doughnut('
            // Datas
            +'['
             +'   {'
                    +'value: 300,'
                    +'color: "#F7464A",'
                    +'highlight: "#FF5A5E",'
                    +'label: "Red"'
                +'},'
                +'{'
                    +'value: 50,'
                    +'color: "#46BFBD",'
                    +'highlight: "#5AD3D1",'
                    +'label: "Green"'
                +'},'
                +'{'
                    +'value: 100,'
                    +'color: "#FDB45C",'
                    +'highlight: "#FFC870",'
                    +'label: "Yellow"'
                +'}'
            +'],'
            // Options
            +'{'
                +'segmentShowStroke: true,'
                +'segmentStrokeColor: "#fff",'
                +'segmentStrokeWidth: 1,'
                +'percentageInnerCutout: 50,'
                +'animationSteps: 100,'
                +'animationEasing: "easeOutBounce",'
                +'animateRotate: true,'
                +'animateScale: false,'
                +'responsive: true,'
                +'maintainAspectRatio: true,'
                +'showScale: true,'
                +'animateScale: true'
            +'});'
    +'}'
    + '</script>'

    +'</script>'

  +'</head><body onload="displayLinechart()">'
  +'<div class="box">'
    +'<canvas id="line-chart" height="450" width="400"></canvas>'
    + '<canvas id="doughnut-chart" height="500" width="500"></canvas>'
    +'<canvas id="donut" height="10" width="10"></canvas>'
  +'</div>'
    +'<button style="border-radius: 10px;border: 5px;width: 80px;height:25px;font-family: Tahoma;background: #f4f4f4;" value="Display Chart" onclick="displayLinechart()">Display Chart</button>'
    + '<button style="border-radius: 10px;border: 5px;width: 80px;height:25px;font-family: Tahoma;background: #f4f4f4;" value="Display Alert" onclick="displayAlert()">Display Alert</button>'
    + '<button style="border-radius: 10px;border: 5px;width: 80px;height:25px;font-family: Tahoma;background: #f4f4f4;" value="Display Doughnut Chart" onclick="doughnutChart()">Display Doughnut Chart</button>'
    + '<form method="post" action="addData">'
  + '<fieldset style="width: 500px;background-color: #ddddff;"><legend>Personal information:</legend>'
  + '<div><label for="name">Name:</label><input type="text" id="name" name="name" /></div>'
  + '<div><label for="email">Email:</label><input type="text" id="email" name="email" /></div>'
  + '<div><label for="street">Street:</label><input type="text" id="streetAddress" name="streetAddress" /></div>'
  + '<div><label for="ort">Ort:</label><input type="text" id="ort" name="ort" /></div>'
  + '<div><label for="addressRegion">Address Region:</label><input type="text" id="addressRegion" name="addressRegion" /></div>'
  + '<div><label for="postalCode">Postal Code:</label><input type="text" id="postalCode" name="postalCode" /></div>'
  + '<div><label for="addressCountry">Address Country:</label><input type="text" id="addressCountry" name="addressCountry" /></div>'
  + '<div><label for="contactType">ContactType:</label><input type="text" id="contactType" name="contactType" /></div>'
  + '<div><label for="telephone">Telephone:</label><input type="text" id="telephone" name="telephone" /></div>'
  + '<div><label for="description">Description:</label><textarea name="description" rows="4" cols="50"></textarea><br></div>'
  + '<div><input id="add" type="submit" style="border-radius: 10px;border: 5px;width: 80px;height:25px;font-family: Tahoma;background: #f4f4f4;" value="add" />'
  +'<a href="readPeople"style="text-decoration:none"><input type="button" style="border-radius: 10px;border: 5px;width: 80px;height:25px;font-family: Tahoma;background: #f4f4f4;" value="Go Home"/></a>'
  +'</div></fieldset></form></body></html>';

// index section
function start(request, response) {
    console.log("Beginn start");
    response.writeHead(200, { 'Content-Type': 'text/html' });
    response.write(
        '<html xmlns="http://www.w3.org/1999/xhtml">'
        + '<head>'
        + '<title>Start</title>'
        + '<script src="js/jquery-1.12.4.js"></script>'
        + '<script src="js/jquery-ui.js"></script>'
        + '<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>'
        + '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />'
        + '<link rel="stylesheet" type="text/css" href="styles.css" />'
        + '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">'
        + '</head>'
        + '<style>'
        + '.btn {'
        + 'background-color: DodgerBlue;'
        + 'border: none;'
        + 'color: white;'
        + 'padding: 12px 16px;'
        + 'font-size: 12px;'
        + 'cursor: pointer;'
        + 'height: 50px;'
        + 'width: 150px;'
        + 'margin: 5px;'
        + '}'
        + '.btn: hover {'
        + 'background-color: RoyalRed;'
        + 'border: 2px solid #555555;'
        + '}'
        + '.button5 {'
        + 'background-color: green;'
        + 'color: black;'
        + 'border: 2px solid #555555;'
        + 'background: url(images/iconPizza.png) no-repeat 5 50px;'
        + '}'
        + '.button6 {'
        + 'background-color: red;'
        + 'color: black;'
        + 'border: 2px solid #555555;'
        + 'background: url(images/iconPizza.png) no-repeat 5 50px;'
        + '}'
        + '</style>'

        + '<script type="text/javascript">'

        + '</script>'
        + '<body>'
        + '<div id="wrapper">'
        + '<div id="header"><h1>System of House</h1>'
        + '<ul style="float:right">'
        + '<a href="#contact">Contact</a><a href="#about">About</a>'
        + '</ul>'
        + '</div>'
        + '<div id="leftcolumn"> Left Column'
        + '</br></br ></br>'
        + '<ul>'
        + '<a href="">'
        + '<button class="btn">'
        + '<i class="fa fa-home"> Home</i>'
        + '</button>'
        + '</a>'
        + '<br />'
        + '<a href="news.html">'
        + '<button class="btn">'
        + '<i class="fa fa"> News</i>'
        + '</button>'
        + '</a>'
        + '<br />'
        + '<a href="contact.html">'
        + '<button class="btn">'
        + '<i class="fa fa"> Contact</i>'
        + '</button>'
        + '</a>'
        + '<br />'
        + '<a href="aboutus.html">'
        + '<button class="btn">'
        + '<i class="fa fa"> About us!!!</i>'
        + '</button>'
        + '</a>'
        + '<br />'
        + '<a href="/readpos">'
        + '<button class="btn">'
        + '<i class="fa fa"> POS</i>'
        + '</button>'
        + '</a>'
        + '<br />'
        + '<a href="/bookings">'
        + '<button class="btn">'
        + '<i class="fa fa"> Booking</i>'
        + '</button>'
        + '</a>'

        + '</ul>'
        + '</div>'
        + '<div id="rightcolumn">'
        + '<fieldset style="position:absolute;top: 100px;left: 250px;width: 670px;height: 150px;border: 3px solid #777171;">'
        + '<legend>ToDo</legend>'
        + '</fieldset>'
        + '<fieldset style="position:absolute;top: 270px;left: 250px;width: 670px;height: 300px;border: 3px solid #777171;">'
        + '<legend>ToDo</legend>'
        + '</fieldset>'
        + '<fieldset style="position:absolute;top: 100px;left: 960px;width: 320px;height: 320px;border: 3px solid #777171;">'
        + '<legend>ToDo</legend>'
        + '<div style="overflow:scroll;height:310px;width:100%;overflow:auto">'
        + '</div>'
        + '</fieldset>'
        + '<fieldset style="position:absolute;top: 440px;left: 960px;width: 320px;height: 130px;border: 3px solid #777171;">'
        + '<legend>ToDo</legend>'
        + '</fieldset>'
        + '</div>'
        + '<h3 style="position:absolute;top: 580px;left: 30px;width: 1200px;height: 30px;border: 3px solid #777171;"></h3>'
        + '</div>'
        + '</body>'
        + '</html>'
    );

    response.end();
}
// end   

// booking section
var objBookings = fs.readFileSync('bookings.json', 'utf8');
var dataBookings = JSON.parse(objBookings);
function readDataBookings(request, response, dataBookings) {
    response.write(
        '<html xmlns="http://www.w3.org/1999/xhtml">'
        + '<head>'
        + '<title>Booking</title>'
        + '<script src="js/jquery-1.12.4.js"></script>'
        + '<script src="js/jquery-ui.js"></script>'
        + '<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>'
        + '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />'
        + '<link rel="stylesheet" type="text/css" href="styles.css" />'
        + '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">'
        + '</head>'
        + '<style>'
        + '.btn {'
        + 'background-color: DodgerBlue;'
        + 'border: none;'
        + 'color: white;'
        + 'padding: 12px 16px;'
        + 'font-size: 12px;'
        + 'cursor: pointer;'
        + 'height: 50px;'
        + 'width: 150px;'
        + 'margin: 5px;'
        + '}'
        + '.btnStorno {'
        + 'background-color: Red;'
        + 'border: none;'
        + 'color: white;'
        + 'padding: 5px 5px;'
        + 'font-size: 10px;'
        + 'cursor: pointer;'
        + 'height: 20px;'
        + 'width: 40px;'
        + 'margin: 3px;'
        + '}'

        + '.btn: hover {'
        + 'background-color: RoyalRed;'
        + 'border: 2px solid #555555;'
        + '}'
        + '.button5 {'
        + 'background-color: green;'
        + 'color: black;'
        + 'border: 2px solid #555555;'
        + 'background: url(images/iconPizza.png) no-repeat 5 50px;'
        + '}'
        + '.button6 {'
        + 'background-color: red;'
        + 'color: black;'
        + 'border: 2px solid #555555;'
        + 'background: url(images/iconPizza.png) no-repeat 5 50px;'
        + '}'
        + '.input {'
        + 'background- image: url("/searchicon.png");'
        + 'background-position: 10px 10px;'
        + 'background-repeat: no-repeat;'
        + 'width: 100 %;'
        + 'font-size: 16px;'
        + 'padding: 10px 20px 10px 30px;'
        + 'border: 1px solid #ddd;'
        + 'margin-bottom: 12px;'
        + '}'

        + '.inputText {'
        + 'background- image: url("/searchicon.png");'
        + 'background-position: 10px 10px;'
        + 'background-repeat: no-repeat;'
        + 'width: 100 %;'
        + 'font-size: 16px;'
        + 'padding: 10px 20px 10px 30px;'
        + 'border: 1px solid #ddd;'
        + 'margin-bottom: 12px;'
        + '}'
        + '</style>'

        + '<script type="text/javascript">'

        + '</script>'
        + '<body>'
        + '<div id="wrapper">'
        + '<div id="header"><h1>Point of Sale</h1>'
        + '<ul style="float:right">'
        + '<li style="float:right"><a href="#contact">Contact</a></li><li style="float:right"><a href="#about">About</a></li>'
        + '</ul>'
        + '</div>'
        + '<div id="leftcolumn"> Left Column'
        + '</br></br ></br>'
        + '<ul>'
        + '<a href="/">'
        + '<button class="btn">'
        + '<i class="fa fa-home"> Home</i>'
        + '</button>'
        + '</a>'
        + '<br />'
        + '<a href="news.html">'
        + '<button class="btn">'
        + '<i class="fa fa"> News</i>'
        + '</button>'
        + '</a>'
        + '<br />'
        + '<a href="contact.html">'
        + '<button class="btn">'
        + '<i class="fa fa"> Contact</i>'
        + '</button>'
        + '</a>'
        + '<br />'
        + '<a href="aboutus.html">'
        + '<button class="btn">'
        + '<i class="fa fa"> About us!!!</i>'
        + '</button>'
        + '</a>'
        + '<br />'
        + '<a href="/readpos">'
        + '<button class="btn">'
        + '<i class="fa fa"> POS</i>'
        + '</button>'
        + '</a>'
        + '<br />'
        + '<a href="/bookings">'
        + '<button class="btn">'
        + '<i class="fa fa"> Booking</i>'
        + '</button>'
        + '</a>'

        + '</ul>'
        + '</div>'
        + '<div id="rightcolumn">'
        + '<fieldset style="position:absolute;top: 100px;left: 250px;width: 670px;border: 3px solid #777171;">'
        + '<legend>ToDo</legend>'
        + '<style>' +
        'table {' +
        'border-spacing: 0;' +
        'border: 1px solid #ddd;' +
        '}' +
        'th {' +
        'cursor: pointer;' +
        '}' +
        'th, td {' +
        'text-align: left;' +
        'padding: 13px;' +
        '}' +
        'tr:nth-child(even) {' +
        'background-color: #f1f1f1' +
        '}' +
        '#inputSearch {' +
        '  background - image: url("/searchicon.png");' +
        '  background - position: 10px 10px;' +
        '  background - repeat: no - repeat;' +
        '  width: 100 %;' +
        '  font - size: 16px;' +
        '  padding: 12px 20px 12px 40px;' +
        '  border: 1px solid #ddd;' +
        '  margin - bottom: 12px;' +
        '}' +
        '#inputSearchCategory {' +
        '  background - image: url("/searchicon.png");' +
        '  background - position: 10px 10px;' +
        '  background - repeat: no - repeat;' +
        '   width: 100 %;' +
        '   font - size: 16px;' +
        '  padding: 12px 20px 12px 40px;' +
        '  border: 1px solid #ddd;' +
        '  margin - bottom: 12px;' +
        '}'
        +
        '</style>' +
        '<script>' +
        ' $(document).ready(function() {' +
        ' $("input").focus(function () {' +
        ' $(this).css("background-color", "#cccccc");' +
        ' });' +
        ' $("input").blur(function () {' +
        ' $(this).css("background-color", "#ffffff");' +
        ' });' +
        '});' +
        + '$(document).ready(function () {'
        + '    $("btnStorno").click(function () {'
        + '        alert("btnStorno");'
        + '    });'
        + ' });'
        + '</script>' +
        '</head>' +
        '<body>' +
        '<script>'+
        'function search() {' +
        'var input, filter, table, tr, td, i;' +
        'input = document.getElementById("inputSearch");' +
        'filter = input.value.toUpperCase();' +
        'table = document.getElementById("dataBookingsTable");' +
        'tr = table.getElementsByTagName("tr");' +
        'for (i = 0; i < tr.length; i++) {' +
        '    td = tr[i].getElementsByTagName("td")[1];' +
        '    if (td) {' +
        '        if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {' +
        '            tr[i].style.display = "";' +
        '        } else {' +
        '            tr[i].style.display = "none";' +
        '        }' +
        '    }' +
        '}' +
        '}' +

        'function searchCategory() {' +
        'var input, filter, table, tr, td, i;' +
        'input = document.getElementById("inputSearchCategory");' +
        'filter = input.value.toUpperCase();' +
        'table = document.getElementById("dataBookingsTable");' +
        'tr = table.getElementsByTagName("tr");' +
        'for (i = 0; i < tr.length; i++) {' +
        '    td = tr[i].getElementsByTagName("td")[3];' +
        '    if (td) {' +
        '        if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {' +
        '            tr[i].style.display = "";' +
        '        } else {' +
        '            tr[i].style.display = "none";' +
        '        }' +
        '    }' +
        '}' +
        '}'+
        
        '  function sortTable(n) {' +
        '    var table, rows, switching, i, x, y, shouldSwitch, dir, switchcount = 0;' +
        '    table = document.getElementById("dataBookingsTable");' +
        '    switching = true;' +
        '    dir = "asc";' +
        '    while (switching) {' +
        '    switching = false;' +
        '    rows = table.getElementsByTagName("TR");' +
        '    for (i = 1; i < (rows.length - 1); i++) {' +
        '      shouldSwitch = false;' +
        '      x = rows[i].getElementsByTagName("TD")[n];' +
        '      y = rows[i + 1].getElementsByTagName("TD")[n];' +
        '      if (dir == "asc") {' +
        '        if (x.innerHTML.toLowerCase() > y.innerHTML.toLowerCase()) {' +
        '          shouldSwitch= true;' +
        '          break;' +
        '        }' +
        '      } else if (dir == "desc") {' +
        '        if (x.innerHTML.toLowerCase() < y.innerHTML.toLowerCase()) {' +
        '          shouldSwitch = true;' +
        '          break;' +
        '        }' +
        '      }' +
        '    }' +
        '    if (shouldSwitch) {' +
        '      rows[i].parentNode.insertBefore(rows[i + 1], rows[i]);' +
        '      switching = true;' +
        '      switchcount ++;' +
        '    } else {' +
        '        if (switchcount == 0 && dir == "asc") {' +
        '          dir = "desc";' +
        '          switching = true;' +
        '        }' +
        '      }' +
        '    }' +
        '  }'   +

        
        'function paginet(i) {' +
        'var table, tr, td, i;' +
        'var iend = i*3;' +
        'var istart = iend-3;' +
        'table = document.getElementById("dataBooksTable");' +
        'tr = table.getElementsByTagName("tr");' +
        'for (i = 1; i < tr.length; i++) {' +
        'if(i >istart && i<=iend ) {' +
        '            tr[i].style.display = "";' +
        '        } else {' +
        '            tr[i].style.display = "none";' +
        '        }' +
        '    }' +
        '}'
        + 'function stornoBooking(key) {'
        + 'var table, tr, td, i;' 
        + 'table = document.getElementById("dataBookingsTable");'
        + 'tr = table.getElementsByTagName("tr");' 
        + 'for (i = 1; i < tr.length; i++) {' 
        +       'if(key===tr[i].cells[1].innerHTML) {'
        +            'tr[i].style.background="red";'
        +'}' 
        +'}'
        +'}'
        + '</script>');
    var date = new Date(); 
    var d = ("0" + date.getDay()).slice(-2), mon = ("0" + (date.getMonth() + 1)).slice(-2), y=date.getFullYear(), h=date.getHours(), min=date.getMinutes();
    var day = date.getDay();
    var dateofday = y+"-"+mon+"-"+d;
    var timeofday = h+":"+min;   
    var today = new Date().toISOString().slice(0, 10);
    console.log("Today: "+today);


    console.log("day: "+day);
    console.log("The date of day is: "+dateofday);
    response.write('<input type="text" class="input" id="inputSearchCategory" onkeyup="searchCategory()" placeholder="Search for Category.." title="Type in a Date">' +
        '<input type="text" id="inputSearch" onkeyup="search()" placeholder="Search for names.." title="Type in a name">' +
        '<table id="dataBookingsTable" cellspacing="0" cellpadding="0" border="0" width="325">' +
        '<th onclick="sortTable(0)">ID</th><th onclick="sortTable(1)">Name</th><th onclick="sortTable(2)">Lastname</th><th onclick="sortTable(3)">Time</th><th onclick="sortTable(5)">NbPerson</th>');
    for (i = 0; i < dataBookings.bookings.length; i++) {
        if(dataBookings.bookings[i].booking.date === today) {
            if(dataBookings.bookings[i].booking.canceled === "true") {
                response.write('<tr style="background:red;color:white" id=' + dataBookings.bookings[i].booking.id + '><td><a href=' + "look" + dataBookings.bookings[i].booking.id + '>' + dataBookings.bookings[i].booking.id + '</a></td>' +
                    '<td>' + dataBookings.bookings[i].booking.name + '</td>' +
                    '<td>' + dataBookings.bookings[i].booking.lastname + '</td>' +
                    '<td>' + dataBookings.bookings[i].booking.time + '</td>' +
                    '<td>' + dataBookings.bookings[i].booking.nbperson + '</td>' +
                    '</tr>'
                  );
            } else {
                response.write('<tr id='+ dataBookings.bookings[i].booking.id +'><td><a href=' + "look" + dataBookings.bookings[i].booking.id + '>' + dataBookings.bookings[i].booking.id + '</a></td>' +
            '<td>' + dataBookings.bookings[i].booking.name + '</td>' +
            '<td>' + dataBookings.bookings[i].booking.lastname + '</td>' +
            '<td>' + dataBookings.bookings[i].booking.time + '</td>' +
            '<td>' + dataBookings.bookings[i].booking.nbperson + '</td>'+
            '<td><button id="btnStorno" class="btnStorno" value="' + dataBookings.bookings[i].booking.name +'" onclick=stornoBooking(this.value)>X</button></td>'+
            '</tr>'
            );
        }    
          
        }
    }
    response.write('</table>'
        + '</fieldset>'
        + '<fieldset style="position:absolute;top: 100px;left: 960px;width: 320px;height: 520px;border: 3px solid #777171;">'
        + '<legend>ToDo 2</legend>'
        + '<input type="text" class="inputText" id="fname" name="fname" placeholder="First name.." title="Type in firt name">'
        + '<input type="text" class="inputText" id="lname" name="lname" placeholder="Last name.." title="Type in last name">'
        + '<input type="date" class="inputText" id="date" name="date" value='+today+' min = "2019-01-01" max = "2019-12-31" >'
        + '<input type="time" class="inputText" id="time" name="time" value='+timeofday+' min = "9:00" max = "18:00" required ><br />'
        + '<input type = "number" class="inputText" id="nbperson" name = "nbperson" min = "1" max = "5" placeholder="number of Person...">'
        + '<input type="text" class="inputText" id="phonenb" name="phonenb" placeholder="telefon..." title="Type in Telefon">'
        + '<input type="text" class="inputText" id="email" name="email" placeholder="email..." title="Type in email">'
        + '<textarea id="infos" class="inputText" name="infos" rows="2" cols="20" placeholder="infos...">Type Infos...</textarea>'
        + '</ br><button id="createBooking" class="btn" onclick=createBooking()>Add Booking &#10003</button>'
        + '</fieldset>'
        + '</div>'
        + '</div>'
        + '<script type="text/javascript">'
        +  'function createBooking() {'
        + 'var bookingArray=[document.getElementById("fname").value, document.getElementById("lname").value, document.getElementById("date").value, document.getElementById("time").value, document.getElementById("nbperson").value, document.getElementById("phonenb").value, document.getElementById("email").value, document.getElementById("infos").value];'
        + 'sendBookingData("http://127.0.0.1:3000/createbooking", bookingArray);'
        + 'document.getElementById("fname").value="";'
        + 'document.getElementById("lname").value="";'
        
        +'}'
        + ' function sendBookingData(url, data) {'
        + '    var xhr = new XMLHttpRequest();'
        + '    xhr.open("POST", url, true);'
        + '    xhr.send(data);'
        + '}'
        +'</script>'
        );
        
    response.write('</body></html>');
    response.end();
}
//end



// BEGIN--- POS
var objProducts = fs.readFileSync('Data.json', 'utf8');
var dataProducts = JSON.parse(objProducts);
var objFolio = fs.readFileSync('folios.json', 'utf8');
var dataFolio = JSON.parse(objFolio);
function readPOS(request, response, dataProducts) {
    console.log("Beginn readPOS");
    response.writeHead(200, { 'Content-Type': 'text/html' });
    response.write(
        '<html xmlns="http://www.w3.org/1999/xhtml">'
        + '<head>'
        + '<title>POS</title>'
        + '<script src="js/jquery-1.12.4.js"></script>'
        + '<script src="js/jquery-ui.js"></script>'
        + '<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>'
        + '<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />'
        + '<link rel="stylesheet" type="text/css" href="styles.css" />'
        + '<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">'
        + '</head>'
        + '<style>'
        + '.btn {'
        + 'background-color: DodgerBlue;'
        + 'border: none;'
        + 'color: white;'
        + 'padding: 12px 16px;'
        + 'font-size: 12px;'
        + 'cursor: pointer;'
        + 'height: 50px;'
        + 'width: 150px;'
        + 'margin: 5px;'
        + '}'
        + '.btn: hover {'
        + 'background-color: RoyalRed;'
        + 'border: 2px solid #555555;'
        + '}'
        + '.button5 {'
        + 'background-color: green;'
        + 'color: black;'
        + 'border: 2px solid #555555;'
        + 'background: url(images/iconPizza.png) no-repeat 5 50px;'
        + '}'
        + '.button6 {'
        + 'background-color: red;'
        + 'color: black;'
        + 'border: 2px solid #555555;'
        + 'background: url(images/iconPizza.png) no-repeat 5 50px;'
        + '}'
        + '</style>'

        + '<script type="text/javascript">'

        + 'function loadCoffee(data){'
        + 'var output="";');
    dataProducts.coffee.forEach(function (element) {
        //response.write('<a href=' + "look" + element.person.name + '>' + element.person.name + '</a></td>' );
        response.write('output+="<input type=button class=btn id=' + element.name + ' onclick=setItem(' + element.name + ',' + element.preis + ') value=' + element.name + '></button>&nbsp";');
    });
    response.write('document.getElementById("products").innerHTML = output;'
        + '}'

        + 'function loadPasta(data){'
        + 'var output="";');
    dataProducts.pasta.forEach(function (element) {
        response.write('output+="<input type=button class=btn id=' + element.name + ' onclick=setItem(' + element.name + ',' + element.preis + ') value=' + element.name + '></button>&nbsp";');
    });
    response.write('document.getElementById("products").innerHTML = output;'
        + '}'


        + 'function loadPizza(data){'
        + 'var output="";');
    dataProducts.pizza.forEach(function (element) {
        response.write('output+="<input type=button class=btn id=' + element.name + ' onclick=setItem(' + element.name + ',' + element.preis + ') value=' + element.name + '></button>&nbsp";');
    });
    response.write('document.getElementById("products").innerHTML = output;'
        + '}'

        + 'function setItem(name,preis) {'
        + '   var table = document.getElementById("items");'
        + '   var row = table.insertRow();'
        + '   var cell1 = row.insertCell(0);'
        + '   var cell2 = row.insertCell(1);'
        + '   var cell3 = row.insertCell(2);'
        + '   var cell4 = row.insertCell(3);'
        + '   var cell5 = row.insertCell(4);'
        + '   cell1.innerHTML = name.value;'
        + '   cell2.innerHTML = preis;'
        + '   cell3.innerHTML = "<input type=number id=quantity name=quantity data-mydata="+preis+" onchange=changeSum(this.value,dataset.mydata) min=1 max=5 value=1>";'
        + '   cell4.innerHTML = "<button class=button6 id=deleteItem data-mydata="+preis+" onclick=deleteItem(this,this.dataset.mydata)>X</button>";'

        + '   document.getElementById("summe").value = parseFloat(document.getElementById("summe").value) + parseFloat(preis);'
        + '}'

        + '  function deleteItem(r,preis) {'
        + '           alert("Delete?");'
        + '           var i = r.parentNode.parentNode.rowIndex;'
        + '           document.getElementById("items").deleteRow(i);'
        + '           document.getElementById("summe").value = parseFloat(document.getElementById("summe").value) - parseFloat(preis);'
        + '    }'
        + '  function changeSum(quantity,preis) {'
        + '           document.getElementById("summe").value = parseFloat(document.getElementById("summe").value) + parseFloat(preis);'
        + '    }'

        + '  function createFolio() {'
        + '     var date = new Date();'
        + '     var d=date.getDay(), m=1+date.getMonth(), y=date.getFullYear();'
        + '     var h=date.getHours(), ms=date.getMinutes(), s=date.getSeconds();'
        + '     var dateofFolio = d+"/"+m+"/"+y;'
        + '     var timeofFolio = h+":"+ms+":"+s;'
        + '     var folioJSON = {"date":[dateofFolio,timeofFolio], "items":[], "sum": document.getElementById("summe").value};'
        + '     var folioARRAY = [dateofFolio,timeofFolio, document.getElementById("summe").value];'
        + '     var table = document.getElementById("items");'
        + '     for(i=0; i<table.rows.length; i++) {'
        + '          folioARRAY.push(table.rows[i].cells[0].innerHTML, table.rows[i].cells[1].innerHTML);'
        + '          folioJSON.items.push({"name": table.rows[i].cells[0].innerHTML, "preis": table.rows[i].cells[1].innerHTML});'
        + '            }'
        + '      sendData("http://127.0.0.1:3000/", folioARRAY);'
        + '      removeItems();'
        + ' }'
        + ' function sendData(url, data) {'
        + '    var xhr = new XMLHttpRequest();'
        + '    xhr.open("POST", url, true);'
        + '    xhr.send(data);'
        + '}'
        + '  function removeItems() {'
        + '           var item={};'
        + '           var table = document.getElementById("items");'
        + '           while (table.rows.length > 0) {'
        + '               table.deleteRow(0);'
        + '            }'
        + '            var productsElements = document.getElementById("products");'
        + '            productsElements.innerHTML = "";'
        + '           document.getElementById("summe").value = 0.0;'
        + '    }'
        + '</script>'
        + '<body>'
        + '<div id="wrapper">'
        + '<div id="header"><h1>Point of Sale</h1>'
        + '<ul style="float:right">'
        + '<li style="float:right"><a href="#contact">Contact</a></li><li style="float:right"><a href="#about">About</a></li>'
        + '</ul>'
        + '</div>'
        + '<div id="leftcolumn"> Left Column'
        + '</br></br ></br>'
        + '<ul>'
        + '<a href="/">'
        + '<button class="btn">'
        + '<i class="fa fa-home"> Home</i>'
        + '</button>'
        + '</a>'
        + '<br />'
        + '<a href="news.html">'
        + '<button class="btn">'
        + '<i class="fa fa"> News</i>'
        + '</button>'
        + '</a>'
        + '<br />'
        + '<a href="contact.html">'
        + '<button class="btn">'
        + '<i class="fa fa"> Contact</i>'
        + '</button>'
        + '</a>'
        + '<br />'
        + '<a href="aboutus.html">'
        + '<button class="btn">'
        + '<i class="fa fa"> About us!!!</i>'
        + '</button>'
        + '</a>'
        + '</ul>'
        + '</div>'
        + '<div id="rightcolumn">'
        + '<fieldset style="position:absolute;top: 100px;left: 250px;width: 670px;height: 150px;border: 3px solid #777171;">'
        + '<legend>Categories</legend>'
        + '<button class="btn" onclick="loadCoffee()">'
        + '<i class="fa fa-coffee"></i>'
        + '</button>&nbsp'
        + '<button class="btn" onclick="loadBeer()">'
        + '<i class="fa fa-beer"></i>'
        + '</button>&nbsp'
        + '<button class="btn" onclick="loadPasta()">'
        + '<i class="fa fa-pasta">Pasta</i>'
        + '</button>&nbsp'
        + '<button class="btn" onclick="loadPizza()">'
        + '<i class="fa fa-pizza">PIZZA</i>'
        + '</button>'
        + '</fieldset>'
        + '<fieldset style="position:absolute;top: 270px;left: 250px;width: 670px;height: 300px;border: 3px solid #777171;">'
        + '<legend>Produkts</legend>'
        + '<div id="products"></div>'
        + '</fieldset>'
        + '<fieldset style="position:absolute;top: 100px;left: 960px;width: 320px;height: 320px;border: 3px solid #777171;">'
        + '<legend>Items</legend>'
        + '<div style="overflow:scroll;height:310px;width:100%;overflow:auto">'
        + '<table id="items">'
        + '</table>'
        + '</div>'
        + '</fieldset>'
        + '<fieldset style="position:absolute;top: 440px;left: 960px;width: 320px;height: 130px;border: 3px solid #777171;">'
        + '<legend>Datensatz</legend>'
        + 'Summe:  <input type="text" id="summe" value="0.00" disabled>&nbsp<button id="createFolio" class="button5" onclick=createFolio()>&#10003</button> <button id="removeItems"class="button6" onclick=removeItems() >X</button>'
        + '</fieldset>'
        + '</div>'
        + '<div id="footer"> This is the Footer </div>'
        + '</div>'
        + '</body>'
        + '</html>'
    );

    response.end();
}
// END--- POS

var server = http.createServer(function (request, response) {
    //console.log("headers host: "+request.headers.host);
    //console.log("headers referer: "+request.headers.referer);
    console.log("url: "+JSON.stringify(request.url));
    //console.log("method: "+request.method);
    //console.log("request: "+request);
    // control for favicon process
    if (request.url === '/favicon.ico') {
        response.writeHead(200, { 'Content-Type': 'image/x-icon' });
        response.end();
        console.log('favicon requested');
        return;
    }
    
      // not the favicon? 
    if(request.method === "GET" && request.url === "/") {
        start(request, response);
    } else if (request.method === "GET" && request.url === "/bookings") {
        readDataBookings(request, response, dataBookings);
    } else if(request.method === "GET" && request.url === "/readpos") {
        readPOS(request, response, dataProducts);
      } else if(request.method === "POST") {
          if(request.url === "/createbooking") {
            var post_data='';
            request.on('data', function (bookingdata) {
                post_data += bookingdata;
                newBookingData = {
                    "booking": { "id": 123, "name": post_data.split(',')[0], "lastname": post_data.split(',')[1], "date": post_data.split(',')[2], "time": post_data.split(',')[3], "telefon": post_data.split(',')[4], "email": post_data.split(',')[5], "nbperson": post_data.split(',')[6], "infos": post_data.split(',')[7], "canceled": "false" }};
                    dataBookings.bookings.push(newBookingData);
                    var dat = JSON.stringify(dataBookings, null, 2);
                    fs.writeFile('bookings.json', dat, finished);
                    function finished(err) {
                      console.log('new set, added');
                    }
 
            });
            request.on('end', function () {
                response.writeHead(200, { 'Content-Type': 'Text/plain' });
                response.end('\n');
            });

        }
         else {
             response.writeHead(404, 'Resource Not Found', {'Content-Type': 'text/html'});
             response.end('<!doctype html><html><head><title>404</title></head><body>404: Resource Not Found</body></html>');
          }
      } else if(request.method==="GET"){
            response.writeHead(405, 'Index', {'Content-Type': 'text/html'});
            return response.end('<!doctype html><html><head><title>405</title></head><body>405: Index</body></html>');
        }
});

server.listen(3000);
console.log("Server started and listening on 3000 Port");
